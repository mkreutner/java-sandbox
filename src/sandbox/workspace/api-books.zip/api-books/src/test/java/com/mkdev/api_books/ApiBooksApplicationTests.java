package com.mkdev.api_books;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiBooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
