package com.mkdev.api_books;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiBooksApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiBooksApplication.class, args);
	}

}
